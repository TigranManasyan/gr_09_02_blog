<?php $__env->startSection("title"); ?>Register
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8"></div>
            <div class="col-md-4">
                <h2>Create Account</h2>
                <form action="<?php echo e(route("register")); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control <?php echo e(($errors->has("name")) ? 'is-invalid' : ''); ?>" id="name" placeholder="John Smith" name="name">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("name")); ?>

                        </span>
                    </div>

                    <div class="mb-3">
                        <label for="avatar" class="form-label">User Avatar</label>
                        <input type="file" class="form-control <?php echo e(($errors->has("avatar")) ? 'is-invalid' : ''); ?>" id="avatar" name="avatar">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("avatar")); ?>

                        </span>
                    </div>

                    <div class="mb-3">
                        <label for="birth_date" class="form-label">Birth Date</label>
                        <input type="date" class="form-control <?php echo e(($errors->has("birth_date")) ? 'is-invalid' : ''); ?>" id="birth_date" name="birth_date">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("birth_date")); ?>

                        </span>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?php echo e(($errors->has("email")) ? 'is-invalid' : ''); ?>" id="email" placeholder="example@mail.ru" name="email">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("email")); ?>

                        </span>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control <?php echo e(($errors->has("password")) ? 'is-invalid' : ''); ?>" id="password" placeholder="****" name="password">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("password")); ?>

                        </span>
                    </div>
                    <button class="btn btn-success">Create Account</button>
                </form>
                <p class="mt-2"><a href="">Sign In</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tigran\gr_09_02\laravel\blog\resources\views/auth/register.blade.php ENDPATH**/ ?>