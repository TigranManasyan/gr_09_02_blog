<?php $__env->startSection("title"); ?>Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8"></div>
            <div class="col-md-4">
                <h2>Login Page</h2>
                <?php if(session("success")): ?>
                    <div class="alert alert-success"><?php echo e(session("success")); ?></div>
                <?php elseif(session("fail")): ?>
                    <div class="alert alert-danger"><?php echo e(session("fail")); ?></div>
                <?php endif; ?>

                <form action="<?php echo e(route("login")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?php echo e(($errors->has("email")) ? 'is-invalid' : ''); ?>" id="email" placeholder="example@mail.ru" name="email">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("email")); ?>

                        </span>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control <?php echo e(($errors->has("password")) ? 'is-invalid' : ''); ?>" id="password" placeholder="****" name="password">
                        <span class="invalid-feedback">
                            <?php echo e($errors->first("password")); ?>

                        </span>
                    </div>
                    <button class="btn btn-primary">Sign In</button>
                </form>
                <p class="mt-2"><a href="">Create Account</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tigran\gr_09_02\laravel\blog\resources\views/auth/login.blade.php ENDPATH**/ ?>